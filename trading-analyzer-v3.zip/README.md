# Trading Analyzer v3

Versión 3: Detección de soportes/resistencias, SL/TP visuales y cálculo según inversión.
Optimizado para iPhone + Streamlit Cloud.

Instrucciones: subir `app.py`, `requirements.txt` y `README.md` a tu repo y desplegar en Streamlit Cloud.