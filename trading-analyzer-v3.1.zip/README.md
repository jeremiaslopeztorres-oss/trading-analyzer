# Trading Analyzer v3.1

Versión 3.1: interfaz central para móvil, señal visible grande, detección de niveles y SL/TP visuales.
Instrucciones: sube `app.py` y `requirements.txt` a tu repo y reinicia la app en Streamlit Cloud.